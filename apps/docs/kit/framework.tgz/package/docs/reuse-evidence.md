# 复用来源与验证边界

日期：2026-10-22。来源项目为相邻 FluidBlock。本文区分来源证据与本项目能力，不直接将旧测试数量移作新项目通过结论。

W1 接续：无界面来源代码和测试已分项复用到本仓，并完成独立构建／包消费；当前结果见 [W1 记录](w1-core.md)。下文“来源证据”保留 W0 时点，不能覆盖本项目后续真实结果。

W2 接续：参考来源 Vue 呈现的容器独占、错误与撤销思路，按新宿主契约独立适配；没有复制产品页面。公共生命周期、Node HTTP 和宿主预检在本仓实现，官方资料与验证见 [W2 记录](w2-hosts.md)。

W3 接续：本仓新增通信／请求适配与独立记录样例，不从 FluidBlock 迁移业务。SQLite、HTTP 与 Fetch 来源及实际验证见 [W3 记录](w3-fullstack.md)；工程外样例复制应用代码、从框架 tarball 消费，不复制框架内部代码。

W4 接续：按已确认 Harness 固定源码语义独立实现四种位置和 Vue 适配，未复制 React 呈现代码；样例复用本仓 W3 业务会话及组件，布局不拥有草稿。注册／选择／声明等待、Vue 生产卸载错误与路由资料的轻量证据索引及包消费结果集中在 [W4 记录](w4-ui.md)，后续优先读取此索引，不重新追完整来源。

W5 接续：PNG 业务在本仓独立实现，使用浏览器原生解码、OffscreenCanvas 和专用线程，不从相邻图片项目搬业务或算法。复用的是公开框架的装配、命令、位置和宿主契约；应用经工程外 tarball 构建而非直接导入框架源文件。API 来源、资源责任及实际图片回读证据见 [W5 记录](w5-browser-tool.md)。

## 来源清单

### 2026-10-23：配置并发的最新上游证据

核对官方 DeepSeek Harness 提交 `687f282e8625c6b8d11ff58211a90524be2e4317`（`0.2.1-rc.2`），不再以旧本地参考副本作当前结论。以下仅为源码阅读结论，不是 Harness 双窗口实测：

- [settings 服务](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/settings/settings/src/index.ts)：宿主持有配置权威；设置写入支持期望修订号，不匹配时拒绝。服务参数可省略修订号，不能泛称所有调用都强制冲突检查。
- [配置编辑器](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/boot/config-editor/src/index.ts)：一次修改中加文件锁、读改写补丁、原子替换及协调运行时，与热重载共享串行入口；不是浏览器页面生命周期锁。应用失败时尝试恢复旧补丁，不保证补偿永不失败。
- [浏览器设置入口](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/client/ui-settings/src/client/index.ts)：接收更新与重连通知后重新读取宿主配置；前端只是投影，不是独立配置真值。

本框架只吸收权威存储、操作级协调、修订冲突与失效通知原则，不复制上游代码或引入其后端。纯静态浏览器适配由 IndexedDB 保存真值、Web Locks 串行管理操作、BroadcastChannel 通知补读；每页运行时独立。Node 继续维持单宿主保护。实现与验证范围见[管理教程](guide/plugin-management.md)和唯一实施计划。

| 来源路径（相对 FluidBlock 根目录） | 复用内容 | 必须保留／补验的内容 |
| --- | --- | --- |
| `src/contracts/runtime.ts` | 服务、作用域、运行句柄、状态与诊断契约 | 状态语义、依赖绑定、只读投影；后续新增语义不能静默改变原行为 |
| `src/runtime-cordis` | Cordis 固定基线适配 | 生命周期、并发关闭、清理失败隔离与 PR #133；超时尚未实现 |
| `src/contracts/composition.ts`、`src/plugin-composition` | 清单、配置、版本、绑定与依赖图预检 | 创建运行时前零激活、错误路径、替代实现、失败撤销 |
| `src/validation-zod`、`src/version-semver` | 成熟校验／版本适配 | 严格结构、JSON 配置、默认预发布语义及第三方边界 |
| `src/presentation-vue` | 最小挂载／卸载与状态投影 | 容器归属、首次失败、双实例与订阅撤销；归可选呈现，不搬入核心 |
| `tests/runtime`、`tests/composition` | 公共契约回归 | 按新公开入口运行，不偷读私有状态或永久导入相邻源码 |
| `tests/architecture/boundaries.test.ts` | 正／负例验证的导入约束 | 扩展服务端边界，不复制“全部 src 禁止 Node”规则误伤合法宿主 |
| `experiments/cordis-runtime`、`patches`、依赖补丁脚本 | 原始行为、固定包与补丁来源 | 安装守卫、补丁可重现、独立消费者安装后的实际行为 |
| `experiments/browser`、`tests/browser` | 浏览器生产产物验收路径 | 不复制成默认产品首页；重建后实际浏览器验证 |

## 当前证据

- 本轮在 FluidBlock 执行 `npm.cmd test`，59 项通过，0 失败／跳过／TODO；目录未改动运行时代码。
- 来源项目既有浏览器记录为 6 项 Chrome 通过，本轮未重跑；见[浏览器记录](../../fluid-block/docs/browser-trial.md)及[清单记录](../../fluid-block/docs/plugin-manifest.md)。
- 已核对来源包清单、TypeScript 配置、浏览器构建脚本与导入规则。来源包为私有试验包，没有可消费框架导出和双目标包构建。
- Cordis 目前是来源包开发依赖，补丁由来源安装脚本应用；尚未证明只装生产依赖或下游间接安装时的运行依赖／补丁交付。不得直接发布后假定消费方正确。
- W0 时本项目只有文档和规则，没有运行时代码、依赖安装、构建或运行通过证据；后续 W1 已落地，详见页首接续。

## 转移规则

逐项读取来源、复制或适配到本项目，保留必要来源说明与测试；不搬走旧文件，不复制 node_modules、output、用户数据或仓库元数据。正式包消费不能依赖相邻源码相对导入，示例和契约测试应改用本项目公开入口。

固定基线暂按来源 `cordis@4.0.0-rc.11` 加上游 PR #133 回移补丁考虑，不顺手升级；安装版本、许可、补丁守卫与可分发方式须在 W1 实际核对。已有版本适配不等于全生态插件均兼容。

通用算法和基础代码从此按新框架来源维护，应用经公开依赖使用；转移完成前保留来源回归，不能同时把两份代码都视为权威新实现。正式应用接入时再明确兼容与退出旧路径。
